from blog import db
# class User:
#    def __init__(self,username,password):
#        self.username = username
#        self.password = password
#
#   def show_my_post(self):
#        print('User is viewing there profile: ')
#
#   def create_my_post(self):
#        print('User is creating new post:')

# U = User('Rupesh','ABC')
# print(U.username)
# print(U.password)
# U.show_my_post()
# U.create_my_post())



class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    image_file = db.Column(db.String(20), nullable=False, default='default.jpg')
    password = db.Column(db.String(60), nullable=False)
