from flask import Flask
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
#app.config['SECRET_KEY'] = '8d0e3c2c5a7ca00d1202c1c9da6e2509'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
app.config['SECRET_KEY'] ='mysecretkey'

db = SQLAlchemy(app)
from blog import routes



