from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SelectField, IntegerField, SubmitField
from wtforms.validators import DataRequired, Email, Length, ValidationError

from final.models import BasicDetails




class RegistrationForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    firstname = StringField('First_Name', validators=[DataRequired(), Length(min=2, max=30)])
    midname = StringField('Mid_Name', validators=[DataRequired(), Length(min=2, max=30)])
    lastname = StringField('Last_name', validators=[DataRequired(), Length(min=2, max=30)])
    gender =SelectField('Gender',choices=[('m','Male'),('f','Female')],validate_choice=True)
    country=SelectField('Country',choices=[('a','America'),('a1','Arab'),('a3','Afganistan'),('a4','Algeria'),('a5','Armania')],validate_choice=True)
    city = SelectField('City',choices=[('K','Kathmandu'),('B','Biratnagar'),('p','Pokhara')],validate_choice=True)
    mobileno=IntegerField('MobileNo',validators=[DataRequired()])
    submit = SubmitField('Sign Up')

    def valid_email(self,email):
        em= BasicDetails.query.filter_by(email=email.data).first()
        if em:
            raise ValidationError("Email is taken ,Please chose another one")