from flask import render_template
from werkzeug.utils import redirect

from final import db, app
from final.forms import RegistrationForm
from final.models import BasicDetails


@app.route("/")
def home():

    return render_template('home.html',tittle='Home-Page')


@app.route("/registration" ,methods=["GET","POST"])
def register():
    form =RegistrationForm()
    if form.validate_on_submit():
          basic_details=BasicDetails(email=form.email.data,password=form.password.data,firstname=form.firstname.data,
          midname=form.midname.data,lastname=form.lastname.data,gender=form.gender.data,country=form.country.data,city=form.city.data,mobileno=form.mobileno.data)

          db.session.add(basic_details)
          db.session.commit()

          return redirect ("/personaldetails")
    return render_template('registration.html',title_name='registration-Page',form=form)



@app.route("/personaldetails",methods=["GET","POST"])
def personal():
    return render_template("personal.html",title_page='personal-info')