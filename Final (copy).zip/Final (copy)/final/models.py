from final import db

class BasicDetails(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(60), nullable=False)
    firstname = db.Column(db.String(120), unique=True, nullable=False)
    midname = db.Column(db.String(120), unique=True, nullable=False)
    lastname = db.Column(db.String(120), unique=True, nullable=False)
    gender = db.Column(db.String(100), nullable=False)
    country = db.Column(db.String(120), nullable=False)
    city = db.Column(db.String(120), nullable=False)
    mobileno = db.Column(db.String(120), unique=True, nullable=False)


class PersonalDetails(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    profilefor=db.Column(db.String(60),nullable=False)
    citizenshipno=db.Column(db.String(60),unique=True,nullable=False)
    maritalstatus = db.Column(db.String(60),nullable=False)
    dateofbirth= db.Column(db.String(120),nullable=False)
    height=db.Column(db.String(60),nullable=False)
    weight= db.Column(db.String(60),nullable=False)
    cast = db.Column(db.String(60),nullable=False)
    religion=db.Column(db.String(60),nullable=False)
    skincolor=db.Column(db.String(60),nullable=False)
    mothertongue=db.Column(db.String(60),nullable=False)

